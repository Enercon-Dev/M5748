/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define AN_PCBTemp_Pin GPIO_PIN_0
#define AN_PCBTemp_GPIO_Port GPIOA
#define AN_VCC_IO_Pin GPIO_PIN_1
#define AN_VCC_IO_GPIO_Port GPIOA
#define AN_IN28V_Pin GPIO_PIN_2
#define AN_IN28V_GPIO_Port GPIOA
#define AN_TestRef_Pin GPIO_PIN_3
#define AN_TestRef_GPIO_Port GPIOA
#define Fault_Pin GPIO_PIN_7
#define Fault_GPIO_Port GPIOA
#define OutSpare_Pin GPIO_PIN_1
#define OutSpare_GPIO_Port GPIOB
#define ISO_FLR_Pin GPIO_PIN_2
#define ISO_FLR_GPIO_Port GPIOB
#define EPO_IN_Pin GPIO_PIN_12
#define EPO_IN_GPIO_Port GPIOB
#define EN_350VDC_Pin GPIO_PIN_13
#define EN_350VDC_GPIO_Port GPIOB
#define BattleMode_Pin GPIO_PIN_14
#define BattleMode_GPIO_Port GPIOB
#define Output350V_OK_Pin GPIO_PIN_15
#define Output350V_OK_GPIO_Port GPIOB
#define Fault_LED_Pin GPIO_PIN_8
#define Fault_LED_GPIO_Port GPIOA
#define InSpare_Pin GPIO_PIN_12
#define InSpare_GPIO_Port GPIOA
#define CAN_EN_Pin GPIO_PIN_4
#define CAN_EN_GPIO_Port GPIOB
#define TX_EN_Pin GPIO_PIN_5
#define TX_EN_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
