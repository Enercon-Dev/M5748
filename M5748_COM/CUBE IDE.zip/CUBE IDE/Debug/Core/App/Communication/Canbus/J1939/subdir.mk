################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/App/Communication/Canbus/J1939/j1939.c \
../Core/App/Communication/Canbus/J1939/j1939_pgn.c \
../Core/App/Communication/Canbus/J1939/j1939_tp.c 

OBJS += \
./Core/App/Communication/Canbus/J1939/j1939.o \
./Core/App/Communication/Canbus/J1939/j1939_pgn.o \
./Core/App/Communication/Canbus/J1939/j1939_tp.o 

C_DEPS += \
./Core/App/Communication/Canbus/J1939/j1939.d \
./Core/App/Communication/Canbus/J1939/j1939_pgn.d \
./Core/App/Communication/Canbus/J1939/j1939_tp.d 


# Each subdirectory must supply rules for building sources it contributes
Core/App/Communication/Canbus/J1939/%.o Core/App/Communication/Canbus/J1939/%.su Core/App/Communication/Canbus/J1939/%.cyclo: ../Core/App/Communication/Canbus/J1939/%.c Core/App/Communication/Canbus/J1939/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App/Communication" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Hardware" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/ISO_11783" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Open_SAE_J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/SAE_J1939" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-App-2f-Communication-2f-Canbus-2f-J1939

clean-Core-2f-App-2f-Communication-2f-Canbus-2f-J1939:
	-$(RM) ./Core/App/Communication/Canbus/J1939/j1939.cyclo ./Core/App/Communication/Canbus/J1939/j1939.d ./Core/App/Communication/Canbus/J1939/j1939.o ./Core/App/Communication/Canbus/J1939/j1939.su ./Core/App/Communication/Canbus/J1939/j1939_pgn.cyclo ./Core/App/Communication/Canbus/J1939/j1939_pgn.d ./Core/App/Communication/Canbus/J1939/j1939_pgn.o ./Core/App/Communication/Canbus/J1939/j1939_pgn.su ./Core/App/Communication/Canbus/J1939/j1939_tp.cyclo ./Core/App/Communication/Canbus/J1939/j1939_tp.d ./Core/App/Communication/Canbus/J1939/j1939_tp.o ./Core/App/Communication/Canbus/J1939/j1939_tp.su

.PHONY: clean-Core-2f-App-2f-Communication-2f-Canbus-2f-J1939

