################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/App/Communication/Canbus/can_driver.c 

OBJS += \
./Core/App/Communication/Canbus/can_driver.o 

C_DEPS += \
./Core/App/Communication/Canbus/can_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Core/App/Communication/Canbus/%.o Core/App/Communication/Canbus/%.su Core/App/Communication/Canbus/%.cyclo: ../Core/App/Communication/Canbus/%.c Core/App/Communication/Canbus/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App/Communication" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Hardware" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/ISO_11783" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Open_SAE_J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/SAE_J1939" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-App-2f-Communication-2f-Canbus

clean-Core-2f-App-2f-Communication-2f-Canbus:
	-$(RM) ./Core/App/Communication/Canbus/can_driver.cyclo ./Core/App/Communication/Canbus/can_driver.d ./Core/App/Communication/Canbus/can_driver.o ./Core/App/Communication/Canbus/can_driver.su

.PHONY: clean-Core-2f-App-2f-Communication-2f-Canbus

