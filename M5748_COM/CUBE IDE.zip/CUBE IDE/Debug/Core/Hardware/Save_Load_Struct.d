Core/Hardware/Save_Load_Struct.o: ../Core/Hardware/Save_Load_Struct.c \
 ../Core/Hardware/Hardware.h \
 ../Core/Hardware/../Open_SAE_J1939/C89_Library.h \
 ../Core/Hardware/../SAE_J1939/SAE_J1939_Enums/Enum_DM14_DM15.h \
 ../Core/Hardware/../SAE_J1939/SAE_J1939_Enums/Enum_Send_Status.h
../Core/Hardware/Hardware.h:
../Core/Hardware/../Open_SAE_J1939/C89_Library.h:
../Core/Hardware/../SAE_J1939/SAE_J1939_Enums/Enum_DM14_DM15.h:
../Core/Hardware/../SAE_J1939/SAE_J1939_Enums/Enum_Send_Status.h:
