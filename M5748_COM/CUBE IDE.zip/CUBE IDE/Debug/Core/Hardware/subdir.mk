################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Hardware/CAN_Transmit_Receive.c \
../Core/Hardware/FLASH_EEPROM_RAM_Memory.c \
../Core/Hardware/Save_Load_Struct.c 

OBJS += \
./Core/Hardware/CAN_Transmit_Receive.o \
./Core/Hardware/FLASH_EEPROM_RAM_Memory.o \
./Core/Hardware/Save_Load_Struct.o 

C_DEPS += \
./Core/Hardware/CAN_Transmit_Receive.d \
./Core/Hardware/FLASH_EEPROM_RAM_Memory.d \
./Core/Hardware/Save_Load_Struct.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Hardware/%.o Core/Hardware/%.su Core/Hardware/%.cyclo: ../Core/Hardware/%.c Core/Hardware/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App/Communication" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Hardware" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/ISO_11783" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Open_SAE_J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/SAE_J1939" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-Hardware

clean-Core-2f-Hardware:
	-$(RM) ./Core/Hardware/CAN_Transmit_Receive.cyclo ./Core/Hardware/CAN_Transmit_Receive.d ./Core/Hardware/CAN_Transmit_Receive.o ./Core/Hardware/CAN_Transmit_Receive.su ./Core/Hardware/FLASH_EEPROM_RAM_Memory.cyclo ./Core/Hardware/FLASH_EEPROM_RAM_Memory.d ./Core/Hardware/FLASH_EEPROM_RAM_Memory.o ./Core/Hardware/FLASH_EEPROM_RAM_Memory.su ./Core/Hardware/Save_Load_Struct.cyclo ./Core/Hardware/Save_Load_Struct.d ./Core/Hardware/Save_Load_Struct.o ./Core/Hardware/Save_Load_Struct.su

.PHONY: clean-Core-2f-Hardware

