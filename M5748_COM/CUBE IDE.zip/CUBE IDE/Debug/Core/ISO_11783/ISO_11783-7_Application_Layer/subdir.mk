################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.c \
../Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.c \
../Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.c \
../Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.c \
../Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.c 

OBJS += \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.o \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.o \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.o \
./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.o \
./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.o 

C_DEPS += \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.d \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.d \
./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.d \
./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.d \
./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.d 


# Each subdirectory must supply rules for building sources it contributes
Core/ISO_11783/ISO_11783-7_Application_Layer/%.o Core/ISO_11783/ISO_11783-7_Application_Layer/%.su Core/ISO_11783/ISO_11783-7_Application_Layer/%.cyclo: ../Core/ISO_11783/ISO_11783-7_Application_Layer/%.c Core/ISO_11783/ISO_11783-7_Application_Layer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App/Communication" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Hardware" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/ISO_11783" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Open_SAE_J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/SAE_J1939" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-ISO_11783-2f-ISO_11783-2d-7_Application_Layer

clean-Core-2f-ISO_11783-2f-ISO_11783-2d-7_Application_Layer:
	-$(RM) ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.cyclo ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.d ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.o ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Command.su ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.cyclo ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.d ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.o ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Estimated_Flow.su ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.cyclo ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.d ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.o ./Core/ISO_11783/ISO_11783-7_Application_Layer/Auxiliary_Valve_Measured_Position.su ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.cyclo ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.d ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.o ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Command.su ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.cyclo ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.d ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.o ./Core/ISO_11783/ISO_11783-7_Application_Layer/General_Purpose_Valve_Estimated_Flow.su

.PHONY: clean-Core-2f-ISO_11783-2f-ISO_11783-2d-7_Application_Layer

