################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.c \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.c \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.c \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.c \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.c \
../Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.c 

OBJS += \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.o \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.o \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.o \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.o \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.o \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.o 

C_DEPS += \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.d \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.d \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.d \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.d \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.d \
./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.d 


# Each subdirectory must supply rules for building sources it contributes
Core/SAE_J1939/SAE_J1939-71_Application_Layer/%.o Core/SAE_J1939/SAE_J1939-71_Application_Layer/%.su Core/SAE_J1939/SAE_J1939-71_Application_Layer/%.cyclo: ../Core/SAE_J1939/SAE_J1939-71_Application_Layer/%.c Core/SAE_J1939/SAE_J1939-71_Application_Layer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App/Communication" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/App" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Hardware" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/ISO_11783" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/Open_SAE_J1939" -I"C:/Projects/Embedded/M5748_COM/CUBE IDE/Core/SAE_J1939" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-SAE_J1939-2f-SAE_J1939-2d-71_Application_Layer

clean-Core-2f-SAE_J1939-2f-SAE_J1939-2d-71_Application_Layer:
	-$(RM) ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Application_Layer.su ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Component_Identification.su ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_ECU_Identification.su ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary.su ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Proprietary_B.su ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.cyclo ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.d ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.o ./Core/SAE_J1939/SAE_J1939-71_Application_Layer/Request_Software_Identification.su

.PHONY: clean-Core-2f-SAE_J1939-2f-SAE_J1939-2d-71_Application_Layer

