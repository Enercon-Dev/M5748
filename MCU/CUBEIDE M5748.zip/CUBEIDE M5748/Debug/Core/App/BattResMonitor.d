Core/App/BattResMonitor.o: ../Core/App/BattResMonitor.c \
 ../Core/App/BattResMonitor.h \
 C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/IntComm.h \
 C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/Command.h \
 C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/IntComm.h \
 C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/DataBuffer.h \
 C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/RowIO.h
../Core/App/BattResMonitor.h:
C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/IntComm.h:
C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/Command.h:
C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/Communication/IntComm.h:
C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/DataBuffer.h:
C:/Projects/Embedded/Projects\ From\ Git/M5748/MCU/CUBEIDE\ M5748/Core/App/RowIO.h:
